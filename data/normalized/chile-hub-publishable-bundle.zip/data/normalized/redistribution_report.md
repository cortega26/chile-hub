# chile-hub redistribution report

- `generated_at_utc`: `2026-06-11T23:01:16.584873+00:00`
- `dataset_count`: `4`
- `ready_count`: `4`
- `review_terms_count`: `0`
- `unknown_count`: `0`

| Dataset | Publishability | License | Attribution | Redistribution | Action |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `regiones` | `ready` | CC BY | `yes` | `ok` | Publicable con atribucion y referencia de fuente. |
| `provincias` | `ready` | CC BY | `yes` | `ok` | Publicable con atribucion y referencia de fuente. |
| `comunas` | `ready` | CC BY | `yes` | `ok` | Publicable con atribucion y referencia de fuente. |
| `indicadores` | `ready` | Reproducción libre con citación (BCCh / INE) | `yes` | `ok` | Publicable con atribucion y referencia de fuente. |

## regiones

- `publishability_status`: `ready`
- `license`: `CC BY`
- `license_url`: https://datos.bcn.cl/es/informacion/lo-que-esta-haciendo-bcn
- `attribution_required`: `True`
- `redistribution_ok`: `True`
- `recommended_action`: Publicable con atribucion y referencia de fuente.
- `summary`: Derivada de datos abiertos BCN reutilizables con atribucion.

## provincias

- `publishability_status`: `ready`
- `license`: `CC BY`
- `license_url`: https://datos.bcn.cl/es/informacion/lo-que-esta-haciendo-bcn
- `attribution_required`: `True`
- `redistribution_ok`: `True`
- `recommended_action`: Publicable con atribucion y referencia de fuente.
- `summary`: Derivada de datos abiertos BCN reutilizables con atribucion.

## comunas

- `publishability_status`: `ready`
- `license`: `CC BY`
- `license_url`: https://datos.bcn.cl/es/informacion/lo-que-esta-haciendo-bcn
- `attribution_required`: `True`
- `redistribution_ok`: `True`
- `recommended_action`: Publicable con atribucion y referencia de fuente.
- `summary`: Fuente operativa BCN dentro de su superficie de datos abiertos; atribucion requerida.

## indicadores

- `publishability_status`: `ready`
- `license`: `Reproducción libre con citación (BCCh / INE)`
- `license_url`: https://www.bcentral.cl/web/banco-central/terminos-y-condiciones
- `attribution_required`: `True`
- `redistribution_ok`: `True`
- `recommended_action`: Publicable con atribucion y referencia de fuente.
- `summary`: Datos del Banco Central de Chile (BCCh) e INE. Libre reproducción con citación. Acceso vía mindicador.cl (API pública de la comunidad).
